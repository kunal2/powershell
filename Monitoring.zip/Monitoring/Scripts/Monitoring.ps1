﻿$FTBM = 'C:\Users\kunal\Desktop\Monitoring\Test'
$FLTR = '*.*'

$watcher = New-Object IO.FileSystemWatcher $FTBM, $FLTR -property @{IncludeSubDirectories = $false; NotifyFilter = [IO.NotifyFilters]'FileName, LastWrite'}

Register-ObjectEvent $watcher Created -SourceIdentifier FileCreated -Action {
$name = $Event.SourceEventArgs.Name
$changeType = $Event.SourceEventArgs.ChangeType
$timeStamp = $Event.TimeGenerated
$projectCode = "Toto"
Write-Host "This file: $name, was $changeType at $timeStamp!, $projectCode"
Out-File -filepath 'C:\Users\kunal\Desktop\Monitoring\Logs\CreationLogs.txt' -append -inputobject "This file: $name, was $changeType at $timeStamp! $projectCode"
}

#Unregister-Event FileCreated